import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss']
})
export class UserlistComponent implements OnInit {
  usersList = [];
  searchString=''
  // searchString:string | undefined;
  constructor(
    private usersService: UsersService,
    private router: Router
  ) {
    this.usersService.getUsers().subscribe((resp: any) => {
      console.log(resp);
      this.usersList = resp

    })

  }

  ngOnInit(): void {
  }
  viewUser(userID: any) {
    this.router.navigate(['userdetails', userID])
  }
}
