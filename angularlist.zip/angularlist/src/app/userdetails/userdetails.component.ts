import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.scss']
})
export class UserdetailsComponent implements OnInit {
  userID:any;
  userDetail:any;
  constructor(
    private route:ActivatedRoute,
    private userService:UsersService
  ) {
     this.userID = this.route.snapshot.paramMap.get('userID');
     this.userService.getUserById(this.userID).subscribe((resp:any)=>{
       console.log(resp);
       this.userDetail=resp;
     })
   }

  ngOnInit(): void {
  }
  // images = ['../../assets/images(1).jpg','../../assets/images.jpg','../../assets/img1.lpg']
  // images = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);

}
